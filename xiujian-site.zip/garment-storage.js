const DATABASE = 'xiujian.pages.wardrobe';
const GARMENTS = 'garments';
const FILES = 'files';
let databasePromise;

function openDatabase() {
  if (!databasePromise) {
    databasePromise = new Promise((resolve, reject) => {
      const request = indexedDB.open(DATABASE, 1);
      request.onupgradeneeded = () => {
        const database = request.result;
        database.createObjectStore(GARMENTS, { keyPath: 'id' });
        database.createObjectStore(FILES, { keyPath: 'id' });
      };
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const database = request.result;
        database.onversionchange = database.onclose = () => {
          database.close();
          databasePromise = undefined;
        };
        resolve(database);
      };
    }).catch(error => {
      databasePromise = undefined;
      throw error;
    });
  }
  return databasePromise;
}

async function transact(stores, mode, run) {
  const database = await openDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(stores, mode);
    let failure, result;
    const finish = value => { result = value; };
    const abort = error => {
      failure = error;
      transaction.abort();
    };
    const read = (request, onSuccess) => {
      // Queue dependent writes while the IndexedDB transaction is still active.
      request.onsuccess = () => {
        try {
          onSuccess(request.result);
        } catch (error) {
          abort(error);
        }
      };
    };
    transaction.oncomplete = () => resolve(result);
    transaction.onabort = () => reject(failure || transaction.error || new Error('衣橱数据未能保存。'));
    try {
      run(transaction, read, finish);
    } catch (error) {
      abort(error);
    }
  });
}

function byLayer(garments) {
  return garments.sort((a, b) => a.layer - b.layer);
}

export function loadWardrobe() {
  return transact([GARMENTS, FILES], 'readonly', (transaction, read, finish) => {
    let metadata, files;
    const collect = () => {
      if (!metadata || !files) return;
      const byId = new Map(files.map(({ id, file }) => [id, file]));
      finish(byLayer(metadata).map(({ layer, ...entry }) => {
        const blob = byId.get(entry.id);
        const file = blob instanceof File && blob.name === entry.filename
          ? blob
          : blob && new File([blob], entry.filename, { type: blob.type });
        return { ...entry, file };
      }));
    };
    read(transaction.objectStore(GARMENTS).getAll(), value => {
      metadata = value;
      collect();
    });
    read(transaction.objectStore(FILES).getAll(), value => {
      files = value;
      collect();
    });
  });
}

export function addGarment({ id, name, filename = undefined, file, visible = true, bodyKey }) {
  return transact([GARMENTS, FILES], 'readwrite', (transaction, read) => {
    const garments = transaction.objectStore(GARMENTS);
    const files = transaction.objectStore(FILES);
    read(garments.getAll(), entries => {
      const layer = entries.reduce((max, entry) => Math.max(max, entry.layer), -1) + 1;
      garments.add({ id, name, filename: filename ?? file.name, visible, bodyKey, layer });
      files.add({ id, file });
    });
  });
}

export function updateGarment(id, { name, visible }) {
  return transact(GARMENTS, 'readwrite', (transaction, read) => {
    const garments = transaction.objectStore(GARMENTS);
    read(garments.get(id), entry => {
      if (!entry) throw new Error('这件衣物已移除，请刷新衣橱。');
      if (name !== undefined) entry.name = name;
      if (visible !== undefined) entry.visible = visible;
      garments.put(entry);
    });
  });
}

export function moveGarment(id, offset) {
  return transact(GARMENTS, 'readwrite', (transaction, read, finish) => {
    if (offset !== -1 && offset !== 1) throw new Error('衣物每次只能移动一层。');
    const garments = transaction.objectStore(GARMENTS);
    read(garments.getAll(), entries => {
      const ordered = byLayer(entries);
      const from = ordered.findIndex(entry => entry.id === id);
      if (from < 0) throw new Error('这件衣物已移除，请刷新衣橱。');
      const to = from + offset;
      if (to >= 0 && to < ordered.length) {
        const first = ordered[from];
        const second = ordered[to];
        const previousLayer = first.layer;
        first.layer = second.layer;
        second.layer = previousLayer;
        garments.put(first);
        garments.put(second);
        ordered[from] = second;
        ordered[to] = first;
      }
      finish(ordered.map(entry => entry.id));
    });
  });
}

export function deleteGarment(id) {
  return transact([GARMENTS, FILES], 'readwrite', transaction => {
    transaction.objectStore(GARMENTS).delete(id);
    transaction.objectStore(FILES).delete(id);
  });
}
