import {createShapeModel} from './shape.mjs';
import {poseVertices} from './pose.mjs';

export function createRuntime(model, appearance, basis, skinIndices, skinWeights) {
  const shape = createShapeModel(model, appearance, basis);
  const rig = {
    labels: model.boneLabels,
    parents: model.boneParents,
    indices: new Uint8Array(skinIndices),
    weights: new Float32Array(skinWeights),
    influences: model.influences,
  };

  function generate(parameters, pose = 'rest') {
    const started = performance.now();
    const {meta, rawVertices, rawBoneHeads} = shape.fitShape(parameters);
    const positions = poseVertices(rawVertices, rawBoneHeads, rig, pose, {
      heightCm: meta.actual.height,
      waistIndices: shape.config.waistVertexIndices,
    });
    const displayActual = shape.measureDisplay(positions);
    return {
      meta: {...meta, pose, displayActual, generationMs: performance.now() - started},
      positions,
    };
  }

  return {config: shape.config, generate};
}
