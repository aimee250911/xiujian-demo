import {createRuntime} from './runtime.mjs';
import {readAsset} from './read-asset.mjs';

function readModelAsset(filename, format = 'arrayBuffer') {
  return readAsset(new URL(`../assets/${filename}`, import.meta.url), format);
}

async function readBasis({basis}) {
  const parts = await Promise.all(basis.files.map(file => readModelAsset(file)));
  const result = new Uint8Array(basis.byteLength);
  let offset = 0;
  for (const part of parts) {
    result.set(new Uint8Array(part), offset);
    offset += part.byteLength;
  }
  if (offset !== result.byteLength) throw new Error('人体计算数据不完整');
  return result.buffer;
}

const metadata = readModelAsset('model.json?v=2', 'json');
const assets = Promise.all([
  metadata,
  metadata.then(readBasis),
  readModelAsset('topology.bin'),
  readModelAsset('skin-indices.bin'),
  readModelAsset('skin-weights.bin'),
]);
// Initialization reports a network failure through the request channel.
assets.catch(() => {});

let runtime;
self.addEventListener('message', async ({data: request}) => {
  const {id, type} = request;
  try {
    if (type === 'start') {
      const [model, basis, topology, indices, weights] = await assets;
      runtime = createRuntime(model, request.appearance, basis, indices, weights);
      self.postMessage({id, result: {config: runtime.config, topology: new Uint32Array(topology)}}, [topology]);
      return;
    }

    const result = runtime.generate(request.parameters, request.pose);
    self.postMessage({id, result}, [result.positions.buffer]);
  } catch (error) {
    self.postMessage({id, error: error.message || '人体计算失败'});
  }
});
