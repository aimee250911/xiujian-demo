import {createRuntime} from './runtime.mjs';

async function readAsset(filename, format = 'arrayBuffer') {
  const response = await fetch(new URL(`../assets/${filename}`, import.meta.url));
  if (!response.ok) throw new Error('人体计算数据加载失败');
  return response[format]();
}

const assets = Promise.all([
  readAsset('model.json', 'json'),
  readAsset('basis.bin'),
  readAsset('topology.bin'),
  readAsset('skin-indices.bin'),
  readAsset('skin-weights.bin'),
]);
// Initialization reports a network failure through the request channel.
assets.catch(() => {});

let runtime;
self.addEventListener('message', async ({data: request}) => {
  const {id, type} = request;
  try {
    if (type === 'start') {
      const [model, basis, topology, indices, weights] = await assets;
      runtime = createRuntime(model, request.appearance, basis, indices, weights);
      self.postMessage({id, result: {config: runtime.config, topology: new Uint32Array(topology)}}, [topology]);
      return;
    }

    const result = runtime.generate(request.parameters, request.pose);
    self.postMessage({id, result}, [result.positions.buffer]);
  } catch (error) {
    self.postMessage({id, error: error.message || '人体计算失败'});
  }
});
