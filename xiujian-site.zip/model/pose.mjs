// The same arm, wrist and finger poses as the original Anny-backed demo.
const IDENTITY = { rotation: [1, 0, 0, 0, 1, 0, 0, 0, 1], translation: [0, 0, 0] };
const FINGER_FLEXION = [[3, 4, 2], [4, 6, 2], [5, 8, 3], [6, 10, 3], [7, 11, 3]];
const FINGER_GROUPING = [0, .60, 0, .84, .82];
const radians = degrees => degrees * Math.PI / 180;
const add = (a, b) => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const subtract = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const scale = (a, factor) => [a[0] * factor, a[1] * factor, a[2] * factor];
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const norm = a => Math.sqrt(dot(a, a));
const unit = a => scale(a, 1 / Math.max(norm(a), 1e-9));

function rotate(rotation, v) {
  return [
    rotation[0] * v[0] + rotation[1] * v[1] + rotation[2] * v[2],
    rotation[3] * v[0] + rotation[4] * v[1] + rotation[5] * v[2],
    rotation[6] * v[0] + rotation[7] * v[1] + rotation[8] * v[2],
  ];
}

function multiplyRotations(a, b) {
  return a.map((_, index) => {
    const row = index - index % 3;
    const column = index % 3;
    return a[row] * b[column] + a[row + 1] * b[column + 3] + a[row + 2] * b[column + 6];
  });
}

function skew(v) {
  return [0, -v[2], v[1], v[2], 0, -v[0], -v[1], v[0], 0];
}

function rotationBetween(from, to) {
  const a = unit(from);
  const b = unit(to);
  const cosine = Math.min(1, Math.max(-1, dot(a, b)));
  const k = skew(cross(a, b));
  const squared = multiplyRotations(k, k);
  const divisor = Math.max(1 + cosine, 1e-8);
  return IDENTITY.rotation.map((value, index) => value + k[index] + squared[index] / divisor);
}

function rotationAround(axis, angle) {
  const sine = Math.sin(angle);
  const complement = 1 - Math.cos(angle);
  const k = skew(axis);
  const squared = multiplyRotations(k, k);
  return IDENTITY.rotation.map((value, index) => value + sine * k[index] + complement * squared[index]);
}

function rotationY(angle) {
  const cosine = Math.cos(angle);
  const sine = Math.sin(angle);
  return [cosine, 0, sine, 0, 1, 0, -sine, 0, cosine];
}

function wristRotation(point, name, pose) {
  const side = name.at(-1);
  const wrist = point(name);
  const elbow = point('lowerarm01.' + side);
  const direction = unit(pose === 'hip' && side === 'L' ? [.08, 0, -1] : subtract(wrist, elbow));
  const palm = subtract(point('finger3-1.' + side), wrist);
  const alignment = rotationBetween(palm, direction);
  const across = subtract(point('finger5-1.' + side), point('finger2-1.' + side));
  const normal = unit(cross(rotate(alignment, across), direction));
  let wanted = unit(subtract([1, 0, 0], scale(direction, direction[0])));
  if (dot(normal, wanted) < 0) wanted = scale(wanted, -1);
  const angle = Math.atan2(dot(direction, cross(normal, wanted)), dot(normal, wanted));
  return multiplyRotations(rotationAround(direction, angle), alignment);
}

function relaxedFingerRotation(point, name, pose) {
  const side = name.at(-1);
  if (pose === 'rest') {
    if (!name.includes('-1.') || name.startsWith('finger1-')) return null;
    const segment = subtract(point(name.replace('-1.', '-2.')), point(name));
    const middle = subtract(point('finger3-2.' + side), point('finger3-1.' + side));
    return rotationBetween(segment, add(scale(unit(segment), .3), scale(unit(middle), norm(segment) * .7)));
  }

  const [finger, joint] = name.split('.')[0].slice('finger'.length).split('-').map(Number);
  const adjacent = point(`finger${finger}-${joint < 3 ? joint + 1 : joint - 1}.${side}`);
  const center = point(name);
  const segment = joint < 3 ? subtract(adjacent, center) : subtract(center, adjacent);
  let direction = unit(segment);
  if (joint === 1 && finger === 1) {
    const closeTo = unit(subtract(point('finger2-2.' + side), center));
    direction = unit(add(scale(direction, .70), scale(closeTo, .30)));
  } else if (joint === 1) {
    const middle = unit(subtract(point('finger3-2.' + side), point('finger3-1.' + side)));
    const blend = FINGER_GROUPING[finger - 1];
    direction = unit(add(scale(direction, 1 - blend), scale(middle, blend)));
  }

  const aim = [side === 'L' ? -1 : 1, 0, 0];
  const inward = unit(subtract(aim, scale(direction, dot(aim, direction))));
  const angle = radians(FINGER_FLEXION[finger - 1][joint - 1]);
  const target = add(scale(direction, Math.cos(angle)), scale(inward, Math.sin(angle)));
  return rotationBetween(segment, target);
}

function hipWristTarget(vertices, { heightCm, waistIndices } = {}) {
  if (!Number.isFinite(heightCm) || !waistIndices?.length) {
    throw new Error('站姿生成缺少人体尺寸。');
  }
  let x = -Infinity;
  let y = 0;
  let z = 0;
  for (const index of waistIndices) {
    x = Math.max(x, vertices[index * 3]);
    y += vertices[index * 3 + 1];
    z += vertices[index * 3 + 2];
  }
  const bodyScale = heightCm / 162;
  return [x + .040 * bodyScale, y / waistIndices.length - .005 * bodyScale, z / waistIndices.length + .070 * bodyScale];
}

function hipShoulderRotation(point, hipWrist) {
  const shoulder = point('upperarm01.L');
  const elbow = point('lowerarm01.L');
  const wrist = point('wrist.L');
  const upperLength = norm(subtract(elbow, shoulder));
  const lowerLength = norm(subtract(wrist, elbow));
  const vector = subtract(hipWrist, shoulder);
  const distance = Math.min(norm(vector), upperLength + lowerLength - .001);
  const axis = unit(vector);
  const along = (upperLength ** 2 - lowerLength ** 2 + distance ** 2) / (2 * distance);
  const aimingOut = [1, .15, 0];
  const outward = unit(subtract(aimingOut, scale(axis, dot(axis, aimingOut))));
  const bend = Math.sqrt(Math.max(0, upperLength ** 2 - along ** 2));
  return rotationBetween(subtract(elbow, shoulder), add(scale(axis, along), scale(outward, bend)));
}

function boneTransforms(rawVertices, boneHeads, rig, pose, dimensions) {
  const boneIndex = new Map(rig.labels.map((label, index) => [label, index]));
  const transforms = [];
  const wristTarget = pose === 'hip' ? hipWristTarget(rawVertices, dimensions) : null;
  let hipWrist;
  for (const [index, name] of rig.labels.entries()) {
    const parent = rig.parents[index] < 0 ? IDENTITY : transforms[rig.parents[index]];
    const toWorld = vector => add(rotate(parent.rotation, vector), parent.translation);
    const point = label => {
      const offset = boneIndex.get(label) * 3;
      return toWorld([boneHeads[offset], boneHeads[offset + 1], boneHeads[offset + 2]]);
    };
    let rotation;
    if (pose === 'hip' && name === 'spine04') {
      rotation = rotationY(radians(3));
    } else if (pose === 'hip' && name === 'upperarm01.L') {
      hipWrist = toWorld(wristTarget);
      rotation = hipShoulderRotation(point, hipWrist);
    } else if (pose === 'hip' && name === 'lowerarm01.L') {
      const elbow = point(name);
      rotation = rotationBetween(subtract(point('wrist.L'), elbow), subtract(hipWrist, elbow));
    } else if (pose !== 'rest' && name.startsWith('upperarm01.')) {
      rotation = rotationY(radians(name.endsWith('.L') ? 28 : -28));
    } else if (name.startsWith('lowerarm01.')) {
      const side = name.at(-1);
      const elbow = point(name);
      const upper = point('upperarm01.' + side);
      const wrist = point('wrist.' + side);
      const target = add(unit(subtract(elbow, upper)), [0, -.08, 0]);
      rotation = rotationBetween(subtract(wrist, elbow), target);
    } else if (name.startsWith('wrist.')) {
      rotation = wristRotation(point, name, pose);
    } else if (name.startsWith('finger')) {
      rotation = relaxedFingerRotation(point, name, pose);
    }
    if (rotation) {
      const pivot = point(name);
      transforms.push({
        rotation: multiplyRotations(rotation, parent.rotation),
        translation: add(subtract(pivot, rotate(rotation, pivot)), rotate(rotation, parent.translation)),
      });
    } else {
      transforms.push(parent);
    }
  }
  return transforms.map(({ rotation, translation }) => ({
    rotation: Float32Array.from(rotation),
    translation: Float32Array.from(translation),
  }));
}

/** Pose native Anny vertices and return the demo's X-right, Y-up coordinates. */
export function poseVertices(rawVertices, rawBoneHeads, rig, pose, dimensions) {
  if (!['rest', 'natural', 'hip'].includes(pose)) throw new Error('不支持这个站姿。');
  const transforms = boneTransforms(rawVertices, rawBoneHeads, rig, pose, dimensions);
  const vertices = new Float32Array(rawVertices.length);
  let floor = Infinity;
  for (let offset = 0, slot = 0; offset < rawVertices.length; offset += 3) {
    const x = rawVertices[offset];
    const y = rawVertices[offset + 1];
    const z = rawVertices[offset + 2];
    let posedX = 0;
    let posedY = 0;
    let posedZ = 0;
    const end = slot + rig.influences;
    for (; slot < end; slot += 1) {
      const weight = rig.weights[slot];
      if (weight === 0) continue;
      const { rotation, translation } = transforms[rig.indices[slot]];
      posedX += weight * (rotation[0] * x + rotation[1] * y + rotation[2] * z + translation[0]);
      posedY += weight * (rotation[3] * x + rotation[4] * y + rotation[5] * z + translation[1]);
      posedZ += weight * (rotation[6] * x + rotation[7] * y + rotation[8] * z + translation[2]);
    }
    vertices[offset] = posedX;
    vertices[offset + 1] = posedZ;
    vertices[offset + 2] = -posedY;
    floor = Math.min(floor, vertices[offset + 1]);
  }
  for (let offset = 1; offset < vertices.length; offset += 3) vertices[offset] -= floor;
  if (!vertices.every(Number.isFinite)) throw new Error('站姿生成失败。');
  return vertices;
}
