export function createModelClient(appearance) {
  const worker = new Worker(new URL('./worker.mjs', import.meta.url), {type: 'module'});
  const pending = new Map();
  let failure;
  let nextId = 0;

  worker.addEventListener('message', ({data}) => {
    const request = pending.get(data.id);
    if (!request) return;
    pending.delete(data.id);
    if (data.error) request.reject(new Error(data.error));
    else request.resolve(data.result);
  });

  function stop() {
    failure = new Error('浏览器无法继续计算人体，请刷新页面');
    for (const request of pending.values()) request.reject(failure);
    pending.clear();
    worker.terminate();
  }
  worker.addEventListener('error', stop);
  worker.addEventListener('messageerror', stop);

  function send(type, inputs) {
    if (failure) return Promise.reject(failure);
    return new Promise((resolve, reject) => {
      const id = nextId++;
      worker.postMessage({id, type, ...inputs});
      pending.set(id, {resolve, reject});
    });
  }

  return {
    get failed() { return Boolean(failure); },
    ready: Promise.resolve(appearance).then(data => send('start', {appearance: data})),
    generate: (parameters, pose) => send('generate', {parameters, pose}),
  };
}
