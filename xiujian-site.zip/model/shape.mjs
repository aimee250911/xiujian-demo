const MATCH_TOLERANCE_CM = 0.15;
const WAIST_FOLLOWUP_CM = 0.03;

function cleanParameters(input, config) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) {
    throw new Error('人体参数必须是对象。');
  }
  const result = { ...config.defaults };
  for (const [name, value] of Object.entries(input)) {
    if (!Object.hasOwn(config.fields, name)) {
      throw new Error('存在不支持的人体参数。');
    }
    const field = config.fields[name];
    if (typeof value !== 'number' || !Number.isFinite(value)) {
      throw new Error(`${field.label}需要有限数值。`);
    }
    if (value < field.min || value > field.max) {
      throw new Error(`${field.label}超出当前调整范围。`);
    }
    result[name] = value;
  }
  return result;
}

// The upstream model uses linear interpolation between adjacent knots.
function axisWeights(value, knots) {
  const clamped = Math.min(knots.at(-1), Math.max(knots[0], value));
  let upper = 1;
  while (upper < knots.length - 1 && clamped > knots[upper]) upper++;
  const ratio = (clamped - knots[upper - 1]) / (knots[upper] - knots[upper - 1]);
  return [[upper - 1, 1 - ratio], [upper, ratio]];
}

function addWeighted(destination, basis, rowOffset, weight) {
  for (let i = 0; i < destination.length; i++) {
    destination[i] += basis[rowOffset + i] * weight;
  }
}

// Keep a bracket, like the Python solver. Periodic bisection prevents a secant
// step from sticking to one endpoint in nearly flat measuring ranges.
function boundedRoot(fn, low, high) {
  let atLow = fn(low);
  let atHigh = fn(high);
  if (atLow === 0) return low;
  if (atHigh === 0) return high;
  if (Math.sign(atLow) === Math.sign(atHigh)) {
    return Math.abs(atLow) < Math.abs(atHigh) ? low : high;
  }
  for (let iteration = 0; iteration < 64; iteration++) {
    const secant = low - atLow * (high - low) / (atHigh - atLow);
    const bisect = iteration % 3 === 2 || secant <= low || secant >= high;
    const next = bisect ? (low + high) / 2 : secant;
    const value = fn(next);
    if (Math.abs(value) < 1e-6) return next;
    if (Math.sign(value) === Math.sign(atLow)) {
      low = next;
      atLow = value;
    } else {
      high = next;
      atHigh = value;
    }
    if (high - low <= 1e-7) break;
  }
  return Math.abs(atLow) < Math.abs(atHigh) ? low : high;
}

function groundNativeVertices(raw, grounded) {
  let ground = Infinity;
  for (let i = 2; i < grounded.length; i += 3) ground = Math.min(ground, raw[i]);
  for (let i = 0; i < grounded.length; i += 3) {
    grounded[i] = raw[i];
    grounded[i + 1] = raw[i + 2] - ground;
    grounded[i + 2] = -raw[i + 1];
  }
}

function measureNative(rawVertices, waistVertices) {
  let floor = Infinity;
  let crown = -Infinity;
  for (let i = 2; i < rawVertices.length; i += 3) {
    floor = Math.min(floor, rawVertices[i]);
    crown = Math.max(crown, rawVertices[i]);
  }
  let length = 0;
  let previous = waistVertices.at(-1) * 3;
  for (const vertex of waistVertices) {
    const start = vertex * 3;
    length += Math.hypot(
      rawVertices[start] - rawVertices[previous],
      rawVertices[start + 1] - rawVertices[previous + 1],
      rawVertices[start + 2] - rawVertices[previous + 2],
    );
    previous = start;
  }
  return { height: (crown - floor) * 100, waist: length * 100 };
}

// This is the same cosmetic attachment transform used by the 3D renderer.
// During solving, only the vertical extents and closed waist ring need to
// be evaluated. No temporary rendered mesh has to be allocated per iteration.
function createDisplayMeasurer(appearance, waistVertices) {
  const { body, headIndices, referenceHeight, referenceHeadBounds } = appearance;
  const [referenceLow, referenceHigh] = referenceHeadBounds;
  const referencePosition = body.positions;
  const mapping = new Map();
  body.sourceIndices.forEach((source, i) => {
    if (!mapping.has(source)) mapping.set(source, i);
  });
  const ring = waistVertices.map(vertex => mapping.get(vertex));
  if (ring.some(vertex => vertex === undefined)) throw new Error('腰围测量点不完整。');

  const vertexCount = body.bindings.length;
  const sources = new Uint32Array(vertexCount * 3);
  const weights = new Float64Array(vertexCount * 3);
  const offsets = new Float64Array(vertexCount * 3);
  const blend = new Float64Array(vertexCount);
  body.bindings.forEach(([ids, influence, offset, mix], i) => {
    const start = i * 3;
    for (let lane = 0; lane < 3; lane++) {
      sources[start + lane] = ids[lane] * 3;
      weights[start + lane] = influence[lane];
      offsets[start + lane] = offset[lane];
    }
    blend[i] = mix;
  });

  function coordinate(points, i, axis, bodyScale, headMin, headScale) {
    const start = i * 3;
    const surface = points[sources[start] + axis] * weights[start]
      + points[sources[start + 1] + axis] * weights[start + 1]
      + points[sources[start + 2] + axis] * weights[start + 2]
      + offsets[start + axis] * bodyScale;
    const mix = blend[i];
    if (mix === 0) return Math.fround(surface);
    const relative = referencePosition[start + axis] - referenceLow[axis];
    const scale = axis === 1 && relative < 0 ? bodyScale : headScale[axis];
    const affine = headMin[axis] + relative * scale;
    return Math.fround(surface * (1 - mix) + affine * mix);
  }

  return function measureDisplay(points) {
    if (points.length !== appearance.canonicalVertexCount * 3) {
      throw new Error('人体坐标无效，无法测量。');
    }
    const headMin = [Infinity, Infinity, Infinity];
    const headMax = [-Infinity, -Infinity, -Infinity];
    for (const index of headIndices) {
      for (let axis = 0; axis < 3; axis++) {
        const value = points[index * 3 + axis];
        headMin[axis] = Math.min(headMin[axis], value);
        headMax[axis] = Math.max(headMax[axis], value);
      }
    }
    let highestNative = -Infinity;
    for (let i = 1; i < points.length; i += 3) highestNative = Math.max(highestNative, points[i]);
    const bodyScale = highestNative / referenceHeight;
    const headScale = headMax.map((max, axis) =>
      (max - headMin[axis]) / (referenceHigh[axis] - referenceLow[axis]));

    let floor = Infinity;
    let crown = -Infinity;
    for (let i = 0; i < vertexCount; i++) {
      const y = coordinate(points, i, 1, bodyScale, headMin, headScale);
      floor = Math.min(floor, y);
      crown = Math.max(crown, y);
    }
    let length = 0;
    const ringPoint = i => [0, 1, 2].map(axis =>
      coordinate(points, i, axis, bodyScale, headMin, headScale));
    let previous = ringPoint(ring.at(-1));
    for (const vertex of ring) {
      const next = ringPoint(vertex);
      length += Math.hypot(next[0] - previous[0], next[1] - previous[1], next[2] - previous[2]);
      previous = next;
    }
    if (!Number.isFinite(length) || !Number.isFinite(crown - floor)) {
      throw new Error('人体坐标无效，无法测量。');
    }
    return { height: (crown - floor) * 100, waist: length * 100 };
  };
}

export function createShapeModel(model, appearance, basisBuffer) {
  const { config, axes, basisCount, localTargets, targets, waistTarget, basePhenotype, boneLabels } = model;
  const basis = basisBuffer instanceof Float32Array ? basisBuffer : new Float32Array(basisBuffer);
  const vertexWidth = config.vertexCount * 3;
  const rowWidth = vertexWidth + boneLabels.length * 3;
  if (basis.length !== (basisCount + localTargets.length * 2) * rowWidth
      || basisCount !== axes.reduce((size, knots) => size * knots.length, 1)
      || appearance.measurementGeometryId !== config.measurement.geometryId) {
    throw new Error('人体计算数据不完整。');
  }
  const measureDisplay = createDisplayMeasurer(appearance, config.waistVertexIndices);
  const localIndex = new Map(localTargets.map((name, i) => [name, i]));
  const weightsPerHeight = axes[1].length * axes[2].length;
  const localOffset = (target, amount) =>
    (basisCount + localIndex.get(target) * 2 + Number(amount < 0)) * rowWidth;

  function fitShape(input) {
    const started = performance.now();
    const parameters = cleanParameters(input, config);
    const localChanges = {};
    const localContribution = new Float64Array(rowWidth);
    for (const [field, targetNames] of Object.entries(targets)) {
      const amount = parameters[field] / 100;
      for (const target of targetNames) {
        localChanges[target] = amount;
        if (amount !== 0) addWeighted(localContribution, basis, localOffset(target, amount), Math.abs(amount));
      }
    }
    const cupsize = 0.5 + parameters.bustShape / 100;
    const chestWeights = axisWeights(cupsize, axes[2]);
    const work = new Float64Array(rowWidth);
    const raw = new Float32Array(rowWidth);
    const grounded = new Float32Array(vertexWidth);
    const evaluated = new Map();

    function mesh(height, weight, waistStrength) {
      work.set(localContribution);
      if (waistStrength !== 0) {
        addWeighted(work, basis, localOffset(waistTarget, waistStrength), Math.abs(waistStrength));
      }
      for (const [hi, hw] of axisWeights(height, axes[0])) {
        for (const [wi, ww] of axisWeights(weight, axes[1])) {
          for (const [ci, cw] of chestWeights) {
            const coefficient = hw * ww * cw;
            if (coefficient !== 0) {
              const row = hi * weightsPerHeight + wi * axes[2].length + ci;
              addWeighted(work, basis, row * rowWidth, coefficient);
            }
          }
        }
      }
      raw.set(work);
      groundNativeVertices(raw, grounded);
    }

    function evaluate(height, weight, waistStrength) {
      const key = [height, weight, waistStrength].map(value => value.toFixed(9)).join(',');
      if (!evaluated.has(key)) {
        mesh(height, weight, waistStrength);
        evaluated.set(key, measureDisplay(grounded));
      }
      return evaluated.get(key);
    }

    let height = 0.37;
    let weight = 0.5;
    let waistStrength = 0;
    // Fit overall shape before using the local waist morph for harder cases.
    for (let iteration = 0; iteration < 2; iteration++) {
      height = boundedRoot(h => evaluate(h, weight, waistStrength).height - parameters.height, 0, 1);
      waistStrength = 0;
      weight = boundedRoot(w => evaluate(height, w, 0).waist - parameters.waist, 0.05, 0.95);
      if (Math.abs(evaluate(height, weight, 0).waist - parameters.waist) > WAIST_FOLLOWUP_CM) {
        waistStrength = boundedRoot(w => evaluate(height, weight, w).waist - parameters.waist, -0.75, 0.75);
      }
    }
    const actual = evaluate(height, weight, waistStrength);
    mesh(height, weight, waistStrength);
    const rawVertices = raw.slice(0, vertexWidth);
    const rawBoneHeads = raw.slice(vertexWidth);
    const errorCm = { height: actual.height - parameters.height, waist: actual.waist - parameters.waist };
    const targetReached = Math.max(Math.abs(errorCm.height), Math.abs(errorCm.waist)) <= MATCH_TOLERANCE_CM;
    const meta = {
      schema: config.schema,
      engine: config.engine,
      commit: config.commit,
      contourVersion: config.contourVersion,
      parameters,
      actual,
      nativeActual: measureNative(rawVertices, config.waistVertexIndices),
      errorCm,
      targetReached,
      measurementVersion: config.measurement.version,
      measurementGeometryId: config.measurement.geometryId,
      measurementDefinition: config.measurement,
      vertexCount: config.vertexCount,
      faceCount: config.faceCount,
      engineParameters: {
        phenotype: { ...basePhenotype, height, weight, cupsize, firmness: 0.5 },
        localChanges: { ...localChanges, [waistTarget]: waistStrength },
      },
      units: 'meter',
      inputUnits: 'cm; local contours are native strength percentages',
      generationMs: performance.now() - started,
      nativeEvaluations: evaluated.size,
      notice: '模型内部测量，未通过真实人体或服装合身校准。',
      cacheHit: false,
    };
    return { meta, rawVertices, rawBoneHeads };
  }

  return { config, fitShape, measureDisplay };
}
