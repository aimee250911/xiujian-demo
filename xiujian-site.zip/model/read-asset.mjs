const TIMEOUT_MS = 20_000;

export async function readAsset(url, format) {
  for (let attempt = 0; attempt < 2; attempt++) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const response = await fetch(url, {signal: controller.signal});
      if (!response.ok) {
        if (attempt === 0 && (response.status === 429 || response.status >= 500)) continue;
        throw new Error(`资源请求失败（HTTP ${response.status}）`);
      }
      return await response[format]();
    } catch (error) {
      if (controller.signal.aborted || error instanceof TypeError) {
        if (attempt === 0) continue;
        throw new Error('人体资源加载失败，请检查网络连接');
      }
      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }
}
