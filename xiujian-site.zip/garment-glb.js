import { LoadingManager } from 'three';
import { GLTFLoader } from './vendor/loaders/GLTFLoader.js';

const GLB_MAGIC = 0x46546c67;
const JSON_CHUNK = 0x4e4f534a;
const BIN_CHUNK = 0x004e4942;
const HEADER_BYTES = 12;
const CHUNK_HEADER_BYTES = 8;
const loadedScenes = new WeakMap();

function invalidFile() {
  return new Error('文件不是有效的 GLB 2.0 模型，请重新导出。');
}

function readDefinition(data) {
  const view = new DataView(data);
  if (
    view.byteLength < HEADER_BYTES + CHUNK_HEADER_BYTES ||
    view.getUint32(0, true) !== GLB_MAGIC ||
    view.getUint32(4, true) !== 2 ||
    view.getUint32(8, true) !== view.byteLength
  ) throw invalidFile();

  let definition;
  let firstChunkEnd;
  for (let offset = HEADER_BYTES; offset < view.byteLength;) {
    if (view.byteLength - offset < CHUNK_HEADER_BYTES) throw invalidFile();
    const length = view.getUint32(offset, true);
    const type = view.getUint32(offset + 4, true);
    const start = offset + CHUNK_HEADER_BYTES;
    const end = start + length;
    if (length % 4 !== 0 || end > view.byteLength) throw invalidFile();
    if (offset === HEADER_BYTES) {
      if (type !== JSON_CHUNK) throw invalidFile();
      firstChunkEnd = end;
      try {
        definition = JSON.parse(new TextDecoder('utf-8', { fatal: true })
          .decode(new Uint8Array(data, start, length)));
      } catch {
        throw invalidFile();
      }
    } else if (type === JSON_CHUNK || (type === BIN_CHUNK && offset !== firstChunkEnd)) {
      throw invalidFile();
    }
    offset = end;
  }
  if (definition?.asset?.version !== '2.0') throw invalidFile();
  return definition;
}

function usesExternalResource(definition) {
  // Core resources and extension fields can declare URIs. Extras are metadata.
  const pending = [definition];
  while (pending.length) {
    for (const [key, value] of Object.entries(pending.pop())) {
      if (key === 'uri' && typeof value === 'string' && !/^data:/i.test(value)) return true;
      if (key !== 'extras' && value && typeof value === 'object') pending.push(value);
    }
  }
  return false;
}

function externalResourceError() {
  return new Error('这个 GLB 引用了外部文件，请将贴图和模型数据嵌入同一个 GLB 后再导入。');
}

export async function loadGarmentGLB(file) {
  if (!file || !/\.glb$/i.test(file.name)) throw new Error('请选择 .glb 文件。');
  const data = await file.arrayBuffer();
  const definition = readDefinition(data);
  if (usesExternalResource(definition)) throw externalResourceError();
  if (!definition.meshes?.length) throw new Error('这个 GLB 里没有衣物网格。');

  const compressed = ['KHR_draco_mesh_compression', 'EXT_meshopt_compression', 'KHR_texture_basisu'];
  const used = definition.extensionsUsed ?? [];
  const required = definition.extensionsRequired ?? [];
  if (used.includes(compressed[0]) || compressed.some(extension => required.includes(extension))) {
    throw new Error('请导出未使用 Draco、Meshopt 或 KTX2 压缩的 GLB。');
  }

  const manager = new LoadingManager();
  manager.setURLModifier(url => {
    // GLTFLoader creates blob URLs when decoding embedded images.
    if (/^(?:data|blob):/i.test(url)) return url;
    throw externalResourceError();
  });
  const gltf = await new GLTFLoader(manager).parseAsync(data, '').catch(error => {
    throw new Error('无法读取这个 GLB，请检查文件并重新导出。', { cause: error });
  });
  const scene = gltf.scene;
  let hasMesh = false;
  scene?.traverse(object => {
    if (object.isMesh && object.geometry?.getAttribute('position')?.count >= 3) hasMesh = true;
    // An imported light should not alter the studio lighting. Keep child transforms.
    if (object.isLight) object.layers.disableAll();
  });
  if (!scene || !hasMesh) {
    disposeScenes(gltf.scenes);
    throw new Error('这个 GLB 的默认场景里没有可显示的衣物网格。');
  }
  loadedScenes.set(scene, gltf.scenes);
  return scene;
}

function disposeScenes(scenes) {
  const geometries = new Set();
  const materials = new Set();
  const skeletons = new Set();
  for (const scene of scenes) {
    scene.traverse(object => {
      if (object.geometry) geometries.add(object.geometry);
      if (Array.isArray(object.material)) {
        for (const material of object.material) materials.add(material);
      } else if (object.material) {
        materials.add(object.material);
      }
      if (object.skeleton) skeletons.add(object.skeleton);
    });
  }

  const textures = new Set();
  const images = new Set();
  for (const material of materials) {
    for (const value of Object.values(material)) {
      if (value?.isTexture) textures.add(value);
    }
    material.dispose();
  }
  for (const texture of textures) {
    const image = texture.source?.data;
    if (typeof image?.close === 'function') images.add(image);
    texture.dispose();
  }
  for (const image of images) image.close();
  for (const geometry of geometries) geometry.dispose();
  for (const skeleton of skeletons) skeleton.dispose();
}

export function disposeGarment(scene) {
  if (!scene) return;
  scene.removeFromParent();
  const scenes = loadedScenes.get(scene);
  if (!scenes) return;
  loadedScenes.delete(scene);
  disposeScenes(scenes);
}
