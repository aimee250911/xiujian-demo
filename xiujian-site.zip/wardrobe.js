import {loadWardrobe,addGarment,updateGarment,moveGarment,deleteGarment} from './garment-storage.js?v=1';

const byId=id=>document.getElementById(id);
const baseLayerPreference='xiujian.pages.wardrobe.base-clothes';

export class Wardrobe {
  constructor({scene,redraw,showBaseClothes,exportReference}){
    this.scene=scene;
    this.redraw=redraw;
    this.showBaseClothes=showBaseClothes;
    this.entries=[];
    this.queue=Promise.resolve();
    this.bodyKey=null;
    this.storageReady=false;
    this.importing=false;
    this.baseClothesVisible=true;
    this.list=byId('wardrobe-list');
    this.template=byId('wardrobe-item-template');
    this.importButton=byId('import-garment');
    this.exportButton=byId('export-garment-reference');
    this.fileInput=byId('garment-file');
    this.baseClothes=byId('garment-base-clothes');
    this.status=byId('garment-status');
    this.warning=byId('garment-body-warning');

    try{this.baseClothes.checked=localStorage.getItem(baseLayerPreference)!=='hidden';}catch{}
    this.importButton.onclick=()=>this.fileInput.click();
    this.fileInput.onchange=()=>{
      const file=this.fileInput.files[0];
      this.fileInput.value='';
      if(file&&!this.importButton.disabled)this.import(file);
    };
    this.exportButton.onclick=exportReference;
    this.baseClothes.onchange=()=>{
      try{localStorage.setItem(baseLayerPreference,this.baseClothes.checked?'visible':'hidden');}catch{}
      this.refreshScene();
    };
    this.queue=this.restore();
  }

  setBodyKey(key){
    this.bodyKey=key;
    this.updateControls();
  }

  updateControls(){
    const hasBody=this.bodyKey!==null;
    this.importButton.disabled=!hasBody||!this.storageReady||this.importing;
    this.exportButton.disabled=!hasBody;
    this.warning.hidden=!this.entries.some(entry=>entry.preview&&entry.bodyKey!==this.bodyKey);
  }

  setStatus(message,state='ready'){
    this.status.textContent=message;
    this.status.dataset.state=state;
  }

  enqueue(action){
    this.queue=this.queue.then(action).catch(error=>{
      this.setStatus(error.message||'衣橱操作未能保存，请重试。','error');
      this.entries.forEach(entry=>this.syncRow(entry));
    });
    return this.queue;
  }

  async restore(){
    this.setStatus('正在读取衣橱…','loading');
    try{
      const saved=await loadWardrobe();
      this.entries=saved.map(entry=>this.makeRow(entry));
      this.syncOrder();
      let failures=0;
      for(const entry of this.entries){
        if(!entry.visible)continue;
        try{
          entry.preview=await this.loadPreview(entry.file);
          this.scene.add(entry.preview.group);
        }catch{
          entry.row.title='此模型暂时无法显示，可以取消显示后重试。';
          failures++;
        }
      }
      this.storageReady=true;
      this.refreshScene();
      this.setStatus(failures? `${failures} 件衣物暂时无法显示` :
        this.entries.length? `已恢复 ${this.entries.length} 件衣物` : '尚未导入衣物',failures?'error':'ready');
    }catch{
      this.setStatus('无法读取此浏览器的衣橱，请刷新后重试。','error');
    }finally{
      this.updateControls();
    }
  }

  async loadPreview(file){
    const {loadGarmentGLB,disposeGarment}=await import('./garment-glb.js?v=1');
    const group=await loadGarmentGLB(file);
    group.traverse(object=>{if(object.isMesh)object.castShadow=true});
    return {group,dispose:()=>disposeGarment(group)};
  }

  refreshScene(){
    for(const [index,entry] of this.entries.entries()){
      entry.preview?.group.traverse(object=>{
        if(!object.isMesh)return;
        // Sort coincident layers without disabling normal 3D occlusion.
        object.renderOrder=index+1;
        const materials=Array.isArray(object.material)?object.material:[object.material];
        for(const material of materials){
          material.polygonOffset=index>0;
          material.polygonOffsetFactor=0;
          material.polygonOffsetUnits=-index;
        }
      });
    }
    const hasPreview=this.entries.some(entry=>entry.preview);
    byId('garment-layers').hidden=!hasPreview;
    const showBase=!hasPreview||this.baseClothes.checked;
    if(showBase!==this.baseClothesVisible){
      this.baseClothesVisible=showBase;
      this.showBaseClothes(showBase);
    }
    this.updateControls();
    this.redraw();
  }

  makeRow(entry){
    const row=this.template.content.firstElementChild.cloneNode(true);
    const control=action=>row.querySelector(`[data-action="${action}"]`);
    Object.assign(entry,{row,nameField:control('name'),visibility:control('visibility'),
      up:control('up'),down:control('down'),remove:control('remove')});
    const saveName=()=>this.rename(entry,entry.nameField.value.trim());
    entry.nameField.onkeydown=event=>{
      if(event.key!=='Enter'||event.isComposing)return;
      event.preventDefault();
      entry.nameField.blur();
    };
    entry.nameField.onblur=saveName;
    entry.visibility.onchange=()=>this.setVisible(entry,entry.visibility.checked);
    entry.up.onclick=()=>this.move(entry,1);
    entry.down.onclick=()=>this.move(entry,-1);
    entry.remove.onclick=()=>this.remove(entry);
    return entry;
  }

  syncRow(entry){
    if(document.activeElement!==entry.nameField)entry.nameField.value=entry.name;
    entry.nameField.setAttribute('aria-label',`衣物名称：${entry.name}`);
    entry.nameField.title=entry.filename;
    entry.visibility.checked=entry.visible;
    entry.visibility.setAttribute('aria-label',`显示 ${entry.name}`);
    entry.up.setAttribute('aria-label',`上移 ${entry.name}`);
    entry.down.setAttribute('aria-label',`下移 ${entry.name}`);
    entry.remove.setAttribute('aria-label',`移除 ${entry.name}`);
  }

  syncOrder(){
    const focused=document.activeElement;
    this.entries.forEach((entry,index)=>{
      this.syncRow(entry);
      entry.up.disabled=index===this.entries.length-1;
      entry.down.disabled=index===0;
    });
    this.list.replaceChildren(...this.entries.slice().reverse().map(entry=>entry.row));
    if(focused?.isConnected&&!focused.disabled)focused.focus({preventScroll:true});
  }

  import(file){
    const bodyKey=this.bodyKey;
    this.importing=true;
    this.updateControls();
    return this.enqueue(async()=>{
      this.setStatus('正在读取衣物模型…','loading');
      const preview=await this.loadPreview(file);
      const entry={id:crypto.randomUUID(),name:file.name.replace(/\.glb$/i,'').trim().slice(0,60)||'未命名衣物',
        filename:file.name,file,visible:true,bodyKey};
      try{
        await addGarment(entry);
      }catch{
        preview.dispose();
        throw new Error('衣物未能保存，请检查浏览器存储空间后重试。');
      }
      entry.preview=preview;
      this.entries.push(this.makeRow(entry));
      this.scene.add(preview.group);
      this.syncOrder();
      this.refreshScene();
      this.setStatus(`已添加「${entry.name}」`);
      entry.nameField.focus();
      entry.nameField.select();
    }).finally(()=>{
      this.importing=false;
      this.updateControls();
    });
  }

  rename(entry,name){
    return this.enqueue(async()=>{
      if(!this.entries.includes(entry))return;
      if(!name||name===entry.name){
        entry.nameField.value=entry.name;
        return;
      }
      await updateGarment(entry.id,{name});
      entry.name=name;
      this.syncRow(entry);
      this.setStatus(`已保存「${name}」`);
    });
  }

  setVisible(entry,visible){
    return this.enqueue(async()=>{
      if(!this.entries.includes(entry))return;
      const preview=visible&&!entry.preview?await this.loadPreview(entry.file):null;
      try{
        await updateGarment(entry.id,{visible});
      }catch(error){
        preview?.dispose();
        throw error;
      }
      entry.visible=visible;
      if(preview){
        entry.preview=preview;
        entry.row.removeAttribute('title');
        this.scene.add(preview.group);
      }else if(!visible){
        entry.preview?.dispose();
        entry.preview=null;
      }
      this.syncRow(entry);
      this.refreshScene();
      this.setStatus(visible?`已显示「${entry.name}」`:`已隐藏「${entry.name}」`);
    });
  }

  move(entry,offset){
    return this.enqueue(async()=>{
      if(!this.entries.includes(entry))return;
      const ids=await moveGarment(entry.id,offset);
      const position=new Map(ids.map((id,index)=>[id,index]));
      this.entries.sort((a,b)=>(position.get(a.id)??-1)-(position.get(b.id)??-1));
      this.syncOrder();
      this.refreshScene();
      this.setStatus('叠穿顺序已保存');
    });
  }

  remove(entry){
    return this.enqueue(async()=>{
      if(!this.entries.includes(entry))return;
      await deleteGarment(entry.id);
      entry.preview?.dispose();
      this.entries=this.entries.filter(item=>item!==entry);
      this.syncOrder();
      this.refreshScene();
      this.setStatus(this.entries.length?`已移除「${entry.name}」`:'尚未导入衣物');
    });
  }
}
