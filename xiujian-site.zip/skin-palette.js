export const SKIN_PALETTE_ID="cf-card-v1";
export const SKIN_PALETTE=[{"code": "CF10", "name": "绒光白", "hex": "#F9E0CE"}, {"code": "CF11", "name": "柔粉白", "hex": "#F6D7D2"}, {"code": "CF12", "name": "自然粉", "hex": "#F4CDBF"}, {"code": "CF20", "name": "柔米白", "hex": "#F1DBC7"}, {"code": "CF21", "name": "自然米", "hex": "#F1D7C4"}];
export const DEFAULT_SKIN=3;
export function resolveSkin(appearance){const code=SKIN_PALETTE.findIndex(s=>s.code===appearance?.skinCode);if(code>=0)return code;if(appearance?.skinPalette===SKIN_PALETTE_ID&&Number.isInteger(appearance.skin)&&appearance.skin>=0&&appearance.skin<SKIN_PALETTE.length)return appearance.skin;return DEFAULT_SKIN;}
