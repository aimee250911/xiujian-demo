import * as THREE from 'three';
import {SkinSystem} from './skin.js?v=bright-all2';
import {SKIN_PALETTE} from './skin-palette.js';

// The released round-head body contains only geometry and binding data.
let packagePromise;
export function loadBodyAppearance() {
  if (!packagePromise) packagePromise = fetch(new URL('./assets/body.json', import.meta.url)).then(async response => {
    if (!response.ok) throw Error('人体外观模型读取失败');
    const data = await response.json();
    if (data.version !== 'xiujian-round-head-v1') throw Error('人体外观版本不匹配');
    return data;
  }).catch(error => { packagePromise = null; throw error; });
  return packagePromise;
}
function makeGeometry(data){
  const g=new THREE.BufferGeometry();
  g.setAttribute('position',new THREE.Float32BufferAttribute(data.positions,3));
  g.setAttribute('uv',new THREE.Float32BufferAttribute(data.uv,2));
  g.setAttribute('color',new THREE.Float32BufferAttribute(data.colors,3));
  g.setIndex(data.indices);for(const group of data.groups)g.addGroup(group.start,group.count,group.materialIndex);
  const normalGeometry=new THREE.BufferGeometry(),count=Math.max(...data.normalSources)+1;
  normalGeometry.setAttribute('position',new THREE.BufferAttribute(new Float32Array(count*3),3));
  normalGeometry.setIndex(data.indices.map(i=>data.normalSources[i]));
  g.normalTopology=normalGeometry;g.normalSources=data.normalSources;
  updateNormals(g);return g;
}
function updateNormals(g){
  const helper=g.normalTopology,p=g.attributes.position.array,q=helper.attributes.position.array;
  for(let i=0;i<g.normalSources.length;i++)q.set(p.subarray(i*3,i*3+3),g.normalSources[i]*3);
  helper.computeVertexNormals();const source=helper.attributes.normal.array;
  if(!g.attributes.normal)g.setAttribute('normal',new THREE.BufferAttribute(new Float32Array(p.length),3));
  const out=g.attributes.normal.array;for(let i=0;i<g.normalSources.length;i++)out.set(source.subarray(g.normalSources[i]*3,g.normalSources[i]*3+3),i*3);
  g.attributes.normal.needsUpdate=true;
}
function frame(data,points){
  const lo=[Infinity,Infinity,Infinity],hi=[-Infinity,-Infinity,-Infinity];
  for(const i of data.headIndices)for(let a=0;a<3;a++){lo[a]=Math.min(lo[a],points[i*3+a]);hi[a]=Math.max(hi[a],points[i*3+a]);}
  let height=0;for(let i=1;i<points.length;i+=3)height=Math.max(height,points[i]);
  return {lo,hi,scale:hi.map((v,a)=>(v-lo[a])/(data.referenceHeadBounds[1][a]-data.referenceHeadBounds[0][a])),bodyScale:height/data.referenceHeight};
}
function updateGeometry(geometry,template,data,points){
  const f=frame(data,points),out=geometry.attributes.position.array,refLo=data.referenceHeadBounds[0],refHi=data.referenceHeadBounds[1];
  for(let i=0;i<template.bindings.length;i++){
    const [ids,weights,offset,w]=template.bindings[i];
    for(let a=0;a<3;a++){
      const source=template.positions[i*3+a];
      let surface=offset[a]*f.bodyScale;for(let j=0;j<3;j++)surface+=points[ids[j]*3+a]*weights[j];
      const affine=a===1?(source>=refLo[1]?f.lo[1]+(source-refLo[1])*f.scale[1]:f.lo[1]+(source-refLo[1])*f.bodyScale):
        (f.lo[a]+f.hi[a])/2+(source-(refLo[a]+refHi[a])/2)*f.scale[a];
      out[i*3+a]=surface*(1-w)+affine*w;
    }
  }
  geometry.attributes.position.needsUpdate=true;updateNormals(geometry);geometry.computeBoundingSphere();
}

export class ApprovedSkinSystem extends SkinSystem {
  constructor(){super();this.head=new THREE.MeshPhysicalMaterial({color:'#ffffff',vertexColors:true,roughness:.58,ior:1.4,specularIntensity:.8});}
  async load(){await super.load();this.avatar=await loadBodyAppearance();}
  createGeometry(canonical){
    if(canonical.attributes.position.count!==this.avatar.canonicalVertexCount)throw Error('圆头与人体不匹配');
    const template=this.avatar.body;this.geometry=makeGeometry(template);
    const weights=new Float32Array(template.sourceIndices.length*2);
    template.sourceIndices.forEach((s,i)=>{weights[i*2]=this.regions.weights[s*2];weights[i*2+1]=this.regions.weights[s*2+1];});
    this.geometry.setAttribute('skinRegion',new THREE.BufferAttribute(weights,2));this.update(canonical);return this.geometry;
  }
  update(canonical){if(!this.geometry||!this.avatar)return;canonical.computeBoundingBox();this.bodyHeight.value=canonical.boundingBox.max.y;updateGeometry(this.geometry,this.avatar.body,this.avatar,canonical.attributes.position.array);}
  measure(waistIndices){
    if(!this.geometry)throw Error('人体尚未准备好，无法测量。');
    const p=this.geometry.attributes.position.array;
    if(!this.waistRenderIndices){
      const lookup=new Map();this.avatar.body.sourceIndices.forEach((source,i)=>{if(!lookup.has(source))lookup.set(source,i)});
      this.waistRenderIndices=waistIndices.map(i=>lookup.get(i));
      if(this.waistRenderIndices.some(i=>i===undefined))throw Error('腰围测量点不完整。');
    }
    let lo=Infinity,hi=-Infinity,length=0;
    for(let i=1;i<p.length;i+=3){lo=Math.min(lo,p[i]);hi=Math.max(hi,p[i]);}
    this.waistRenderIndices.forEach((id,i)=>{const next=this.waistRenderIndices[(i+1)%this.waistRenderIndices.length];length+=Math.hypot(p[id*3]-p[next*3],p[id*3+1]-p[next*3+1],p[id*3+2]-p[next*3+2]);});
    return {height:(hi-lo)*100,waist:length*100};
  }
  hideCoveredVertices(hidden){
    const template=this.avatar.body,indices=[];this.geometry.clearGroups();
    for(const group of template.groups){const start=indices.length;for(let i=group.start;i<group.start+group.count;i+=3){
      const face=template.indices.slice(i,i+3);if(!face.every(v=>hidden.has(template.sourceIndices[v])))indices.push(...face);
    }this.geometry.addGroup(start,indices.length-start,group.materialIndex);}
    this.geometry.setIndex(indices);
  }
  materials(index,finish='natural'){
    const materials=super.materials(index,finish),linear=x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4;
    const goal=SKIN_PALETTE[index].hex,ref=SKIN_PALETTE[3].hex;
    this.head.color.setRGB(...[1,3,5].map(i=>(linear(parseInt(goal.slice(i,i+2),16)/255)/linear(parseInt(ref.slice(i,i+2),16)/255))**.65));
    return [...materials,this.head];
  }
}
