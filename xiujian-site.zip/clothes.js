import * as THREE from 'three';

// Native MHCLO barycentric binding in MakeHuman's Y-up coordinates, in metres.
// Smooth only the depth of the bandeau interior; pin the hem and preserve X/Y.
// Work before UV splitting so duplicate seam vertices cannot separate.
function preparePanel(data){
  const neighbors=Array.from({length:data.offsets.length/3},()=>new Set()),edges=new Map();
  for(let t=0;t<data.indices.length;t+=3){const f=data.indices.slice(t,t+3).map(i=>data.sourceIndices[i]);for(let j=0;j<3;j++){const a=f[j],b=f[(j+1)%3];neighbors[a].add(b);neighbors[b].add(a);const key=a<b?`${a}:${b}`:`${b}:${a}`;edges.set(key,(edges.get(key)||0)+1);}}
  const boundary=new Set();for(const [key,n]of edges)if(n===1)for(const i of key.split(':'))boundary.add(Number(i));
  return {neighbors:neighbors.map(n=>[...n]),boundary,scratch:new Float32Array(neighbors.length)};
}
function smoothPanel(out,panel){
  const {neighbors,boundary,scratch}=panel;
  // Depth-only diffusion suppresses small peaks without shrinking the whole garment.
  for(let pass=0;pass<36;pass++){
    for(let i=0;i<neighbors.length;i++){let z=out[i*3+2];if(!boundary.has(i)&&neighbors[i].length){let sum=0;for(const j of neighbors[i])sum+=out[j*3+2];z+=(sum/neighbors[i].length-z)*.45;}scratch[i]=z;}
    for(let i=0;i<neighbors.length;i++)out[i*3+2]=scratch[i];
  }
}
export class ClothesSystem {
  constructor(scene){this.scene=scene;this.assets=[];this.hiddenVertices=new Set();}
  async load(){
    for(const id of ['bandeau','shorts']){
      const r=await fetch(`./clothes/${id}.json`);if(!r.ok)throw Error('基础内搭读取失败');const data=await r.json();
      const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.BufferAttribute(new Float32Array(data.sourceIndices.length*3),3));geometry.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(data.uv),2));geometry.setIndex(data.indices);
      const material=new THREE.MeshStandardMaterial({color:'#ffffff',roughness:.92,metalness:0,side:THREE.DoubleSide});
      const mesh=new THREE.Mesh(geometry,material);mesh.name=`White_${id}`;mesh.castShadow=true;mesh.userData={author:data.author,license:data.license,source:data.source,fitting:'MakeHuman MHCLO barycentric binding; white material adaptation'};this.scene.add(mesh);
      const canonical=new THREE.BufferGeometry();const out=new Float32Array(data.offsets.length);canonical.setAttribute('position',new THREE.BufferAttribute(out,3));canonical.setIndex(data.indices.map(i=>data.sourceIndices[i]));geometry.setAttribute('normal',new THREE.BufferAttribute(new Float32Array(data.sourceIndices.length*3),3));this.assets.push({data,mesh,out,canonical,panel:data.id==='bandeau'?preparePanel(data):null});for(const v of data.deleteVertices)this.hiddenVertices.add(v);
    }
  }
  update(canonical){const points=canonical.attributes.position.array;
    for(const {data,mesh,out,canonical,panel}of this.assets){
      const scale=data.scales.map(([i,j,ref],axis)=>Math.abs(points[i*3+axis]-points[j*3+axis])/ref);
      for(let i=0;i<out.length;i+=3)for(let axis=0;axis<3;axis++){let v=data.offsets[i+axis]*scale[axis];for(let j=0;j<data.bindingStride;j++){const k=(i/3)*data.bindingStride+j;v+=points[data.bindingIndices[k]*3+axis]*data.bindingWeights[k];}out[i+axis]=v;}
      if(panel)smoothPanel(out,panel);
      canonical.computeVertexNormals();const normals=canonical.attributes.normal.array,destNormals=mesh.geometry.attributes.normal.array;const p=mesh.geometry.attributes.position.array;for(let i=0;i<data.sourceIndices.length;i++){const n=data.sourceIndices[i]*3;p.set(out.subarray(n,n+3),i*3);destNormals.set(normals.subarray(n,n+3),i*3);}
      mesh.geometry.attributes.position.needsUpdate=true;mesh.geometry.attributes.normal.needsUpdate=true;mesh.geometry.computeBoundingSphere();
    }
  }
  exportMeshes(){return this.assets.map(({mesh})=>{const m=new THREE.Mesh(mesh.geometry.clone(),mesh.material.clone());m.name=mesh.name;m.userData={...mesh.userData};return m;});}
}
