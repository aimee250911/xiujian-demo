import * as THREE from 'three';
import {SKIN_PALETTE} from './skin-palette.js';

// Canonical Anny vertices remain the source of shape and measurements.
// Only render vertices split at native UV seams; normals come from the canonical mesh.
export class SkinSystem {
  constructor(){this.data=null;this.geometry=null;this.maps=[];this.ready=false;this.finish='natural';this.index=3;
    this.natural=new THREE.MeshPhysicalMaterial({color:'#ffffff',roughness:.58,metalness:0,ior:1.4,specularIntensity:.8});
    this.bodyHeight={value:1.53};
    this.handTone={value:new THREE.Vector3(.694,.418,.270)};
    this.natural.onBeforeCompile=shader=>{
      shader.uniforms.uSkinBodyHeight=this.bodyHeight;shader.uniforms.uHandTone=this.handTone;
      shader.vertexShader='attribute vec2 skinRegion; varying vec2 vSkinRegion; varying float vSkinHeight;\n'+shader.vertexShader;
      shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvSkinHeight=position.y;vSkinRegion=skinRegion;');
      shader.fragmentShader='uniform float uSkinBodyHeight; uniform vec3 uHandTone; varying vec2 vSkinRegion;\nvarying float vSkinHeight;\n'+shader.fragmentShader;
      shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',`#include <map_fragment>
        #ifdef USE_MAP
          // Reject isolated dark texels using the surrounding skin, preserving broad features.
          vec3 skinSamples[9];float skinLuma[9];
          for(int j=0;j<9;j++){
            vec2 delta=vec2(float(j/3)-1.,float(j-3*(j/3))-1.)*.0035;
            skinSamples[j]=texture2D(map,vMapUv+delta).rgb;
            skinLuma[j]=dot(skinSamples[j],vec3(.2126,.7152,.0722));
          }
          for(int a=0;a<8;a++)for(int b=0;b<8;b++)if(skinLuma[b]>skinLuma[b+1]){
            float l=skinLuma[b];skinLuma[b]=skinLuma[b+1];skinLuma[b+1]=l;
            vec3 c=skinSamples[b];skinSamples[b]=skinSamples[b+1];skinSamples[b+1]=c;
          }
          vec3 originalSkin=texture2D(map,vMapUv).rgb;
          float originalLuma=dot(originalSkin,vec3(.2126,.7152,.0722));
          float isolatedDark=smoothstep(.025,.10,(skinLuma[4]-originalLuma)/max(skinLuma[4],.01));
          // Facial landmarks stay sharp; larger navel/fold areas remain in the median.
          float belowFace=1.-smoothstep(.82,.88,vSkinHeight/uSkinBodyHeight);
          vec3 cleanSkin=mix(originalSkin,skinSamples[4],isolatedDark*belowFace);
          diffuseColor.rgb*=cleanSkin/max(originalSkin,vec3(.001));
        #endif
      `);
      shader.fragmentShader=shader.fragmentShader.replace('#include <color_fragment>',`#include <color_fragment>
        float skinH=vSkinHeight/uSkinBodyHeight;
        float legs=clamp(vSkinRegion.x,0.,1.)*smoothstep(.035,.10,skinH)*(1.-smoothstep(.43,.54,skinH));
        float knees=exp(-pow((skinH-.275)/.041,2.))*legs;
        // Local leg correction followed by a modest global skin lift.
        diffuseColor.rgb*=vec3(1.)+legs*vec3(.12,.20,.22)+knees*vec3(.04,.13,.14);
        diffuseColor.rgb=mix(diffuseColor.rgb,vec3(.60,.36,.24),knees*.48);
        // Blend texture discoloration toward the forearm's calibrated base color.
        // Native wrist weights feather the correction across the join in every pose.
        float handBlend=smoothstep(0.,1.,clamp(vSkinRegion.y,0.,1.));
        diffuseColor.rgb=mix(diffuseColor.rgb,uHandTone,handBlend*.78);
        diffuseColor.rgb*=1.62;
      `);
    };
    this.natural.customProgramCacheKey=()=> 'anatomical-hand-tone-bright-v2';
    this.reference=new THREE.MeshStandardMaterial({roughness:.83,metalness:0});
    this.eyes=new THREE.MeshPhysicalMaterial({color:'#ffffff',roughness:.38,ior:1.4,specularIntensity:.7});this.eyeReference=new THREE.MeshStandardMaterial({roughness:.83});
  }
  async load(){
    const [r,regions,texture]=await Promise.all([fetch('./skin/body-uv.json'),fetch('./skin/regions.json'),new THREE.TextureLoader().loadAsync('./skin/base-color.png')]);
    if(!r.ok)throw Error('皮肤坐标读取失败');this.data=await r.json();if(!regions.ok)throw Error('皮肤部位数据读取失败');this.regions=await regions.json();if(this.regions.canonicalVertexCount!==this.data.canonicalVertexCount)throw Error('皮肤部位与人体不匹配');
    const source=document.createElement('canvas');source.width=source.height=1024;const ctx=source.getContext('2d',{willReadFrequently:true});ctx.drawImage(texture.image,0,0,1024,1024);const pixels=ctx.getImageData(0,0,1024,1024);texture.dispose();
    const linear=x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4;
    const srgb=x=>x<=.0031308?x*12.92:1.055*x**(1/2.4)-.055;
    const rgb=hex=>[1,3,5].map(i=>linear(parseInt(hex.slice(i,i+2),16)/255));const ref=rgb(SKIN_PALETTE[3].hex);
    for(const swatch of SKIN_PALETTE){const goal=rgb(swatch.hex),factors=goal.map((v,i)=>(v/ref[i])**.65);const lut=factors.map(f=>Uint8Array.from({length:256},(_,n)=>Math.round(Math.max(0,Math.min(1,srgb(linear(n/255)*f)))*255)));
      const canvas=document.createElement('canvas');canvas.width=canvas.height=1024;const c=canvas.getContext('2d');const data=new Uint8ClampedArray(pixels.data);for(let i=0;i<data.length;i+=4){data[i]=lut[0][data[i]];data[i+1]=lut[1][data[i+1]];data[i+2]=lut[2][data[i+2]];}
      c.putImageData(new ImageData(data,1024,1024),0,0);const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('皮肤贴图生成失败');const map=new THREE.CanvasTexture(canvas);map.colorSpace=THREE.SRGBColorSpace;map.anisotropy=4;map.userData.embeddedBytes=new Uint8Array(await blob.arrayBuffer());map.userData.skinCode=swatch.code;this.maps.push(map);
    }
    const eyeCanvas=document.createElement('canvas');eyeCanvas.width=eyeCanvas.height=256;const eye=eyeCanvas.getContext('2d');eye.fillStyle='#d7d1c7';eye.fillRect(0,0,256,256);const iris=eye.createRadialGradient(128,128,10,128,128,55);iris.addColorStop(0,'#2f2723');iris.addColorStop(.4,'#614b3c');iris.addColorStop(.85,'#514139');iris.addColorStop(1,'#2b2927');eye.fillStyle=iris;eye.beginPath();eye.arc(128,128,55,0,Math.PI*2);eye.fill();eye.fillStyle='#171718';eye.beginPath();eye.arc(128,128,24,0,Math.PI*2);eye.fill();const eyeBlob=await new Promise(resolve=>eyeCanvas.toBlob(resolve,'image/png'));this.eyes.map=new THREE.CanvasTexture(eyeCanvas);this.eyes.map.colorSpace=THREE.SRGBColorSpace;this.eyes.map.userData.embeddedBytes=new Uint8Array(await eyeBlob.arrayBuffer());
    this.ready=true;
  }
  createGeometry(canonical){if(!this.data||canonical.attributes.position.count!==this.data.canonicalVertexCount)throw Error('皮肤与人体顶点不匹配');const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(this.data.sourceIndices.length*3),3));g.setAttribute('normal',new THREE.BufferAttribute(new Float32Array(this.data.sourceIndices.length*3),3));g.setAttribute('uv',new THREE.BufferAttribute(new Float32Array(this.data.uv),2));const regions=new Float32Array(this.data.sourceIndices.length*2);for(let i=0;i<this.data.sourceIndices.length;i++){const j=this.data.sourceIndices[i]*2;regions[i*2]=this.regions?.weights[j]||0;regions[i*2+1]=this.regions?.weights[j+1]||0;}g.setAttribute('skinRegion',new THREE.BufferAttribute(regions,2));g.setIndex(this.data.indices);for(const group of this.data.groups)g.addGroup(group.start,group.count,group.materialIndex);this.geometry=g;this.update(canonical);return g;}
  update(canonical){if(!this.geometry)return;canonical.computeBoundingBox();this.bodyHeight.value=canonical.boundingBox.max.y;const p=canonical.attributes.position.array,n=canonical.attributes.normal.array,out=this.geometry.attributes.position.array,normals=this.geometry.attributes.normal.array;for(let i=0;i<this.data.sourceIndices.length;i++){const source=this.data.sourceIndices[i]*3;out[i*3]=p[source];out[i*3+1]=p[source+1];out[i*3+2]=p[source+2];normals[i*3]=n[source];normals[i*3+1]=n[source+1];normals[i*3+2]=n[source+2];}this.geometry.attributes.position.needsUpdate=true;this.geometry.attributes.normal.needsUpdate=true;this.geometry.computeBoundingSphere();}
  hideCoveredVertices(hidden){if(!this.geometry)return;const indices=[],groups=[];for(const group of this.data.groups){const start=indices.length;for(let i=group.start;i<group.start+group.count;i+=3){const face=this.data.indices.slice(i,i+3);if(!face.every(v=>hidden.has(this.data.sourceIndices[v])))indices.push(...face);}groups.push({start,count:indices.length-start,materialIndex:group.materialIndex});}this.geometry.setIndex(indices);this.geometry.clearGroups();for(const g of groups)this.geometry.addGroup(g.start,g.count,g.materialIndex);}
  materials(index,finish='natural'){this.index=index;this.finish=finish;this.natural.map=this.maps[index];const linear=x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4;const goal=SKIN_PALETTE[index].hex,ref=SKIN_PALETTE[3].hex;this.handTone.value.set(...[.694,.418,.270].map((v,i)=>v*(linear(parseInt(goal.slice(1+i*2,3+i*2),16)/255)/linear(parseInt(ref.slice(1+i*2,3+i*2),16)/255))**.65));this.natural.needsUpdate=true;this.reference.color.set(SKIN_PALETTE[index].hex);this.eyeReference.color.set(SKIN_PALETTE[index].hex);return[finish==='reference'?this.reference:this.natural,finish==='reference'?this.eyeReference:this.eyes];}
}
